package com.quinnox.bankwebservoce;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class HDFCBank {

	private int accountNumber;
	private String accountHolderName;
	private String branch;
	private int amount;
	
	public HDFCBank(int accountNumber, String accountHolderName, String branch, int amount) 
	{
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.branch = branch;
		this.amount = amount;
	}
	
	public HDFCBank(String accountHolderName) 
	{
		this.accountHolderName = accountHolderName;
	}
	
	public HDFCBank() 
	{
	}

	public int getAccountNumber() 
	{
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) 
	{
		this.accountNumber = accountNumber;
	}

	public String getAccountHolderName()
	{
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) 
	{
		this.accountHolderName = accountHolderName;
	}

	public String getBranch() 
	{
		return branch;
	}

	public void setBranch(String branch)
	{
		this.branch = branch;
	}

	public int getAmount() 
	{
		return amount;
	}

	public void setAmount(int amount)
	{
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "\t\tHDFC Bank\n\t\t*********\n AccountNumber =" + accountNumber + ",Account Holder Name=" + accountHolderName + ", Branch Office="
				+ branch + ", Balance=" + amount ;
	}

	
	
}