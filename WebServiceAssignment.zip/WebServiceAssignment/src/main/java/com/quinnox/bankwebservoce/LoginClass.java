package com.quinnox.bankwebservoce;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class LoginClass {

	private String userName;
	private String password;
	
	public LoginClass(String userName, String password) 
	{
		this.userName = userName;
		this.password = password;
	}
	
	public LoginClass() 
	{
	}
	public String getUserName()
	{
		return userName;
	}
	public void setUserName(String userName)
	{
		this.userName = userName;
	}
	public String getPassword()
	{
		return password;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}

	@Override
	public String toString() {
		return userName + "," +password;
	}
	
	
	
}