package com.quinnox.bankwebservoce;

import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;

public class HDFCBankRepository 
{ 
	
	
	public List<HDFCBank> getAllBankCustomerDetails() throws Exception
	{
		
		 Connection con = BankDatabaseConnectivity.getConnection();
		 String query = "SELECT * FROM HDFCBankDetails";
		 Statement st =  con.createStatement();
		 ResultSet rs =  st.executeQuery(query);
		 
		 List<HDFCBank> detail = new ArrayList<>();
		 
		 while(rs.next())
		 {
			 HDFCBank hb = new HDFCBank();
			 
			 hb.setAccountNumber(rs.getInt("accountNumber"));
			 hb.setAccountHolderName(rs.getString("accountHolderName"));
			 hb.setBranch(rs.getNString("branch"));
			 hb.setAmount(rs.getInt("amount"));
			 
			 detail.add(hb);

		 }
			
		return detail;	
	}
	
	public void insertAccountDetail(HDFCBank hb) throws Exception

	{
		Connection con = BankDatabaseConnectivity.getConnection();
		String query = "INSERT INTO HDFCBankDetails VALUES(?, ?, ?, ?)";
		PreparedStatement ps =  con.prepareStatement(query);
		
		ps.setInt(1, hb.getAccountNumber());
		ps.setString(2, hb.getAccountHolderName());
		ps.setString(3, hb.getBranch());
		ps.setInt(4, hb.getAmount());
		
		ps.executeUpdate();

	}

	public List<HDFCBank> getAccountBasedOnAccountNumber(int accountNumber) throws Exception
	{
		Connection con = BankDatabaseConnectivity.getConnection();
		String query =  "Select * From HDFCBankDetails WHERE accountNumber ="+accountNumber;
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(query);
		
		List<HDFCBank> detail = new ArrayList<>();

		
		while(rs.next())
		 {
			 HDFCBank hb = new HDFCBank();
			 
			 hb.setAccountNumber(rs.getInt("accountNumber"));
			 hb.setAccountHolderName(rs.getString("accountHolderName"));
			 hb.setBranch(rs.getNString("branch"));
			 hb.setAmount(rs.getInt("amount"));
			 
			 detail.add(hb);
		 }
			
		return detail;	
	}
	
	public void updateAccountName(int accountNumber, HDFCBank hb) throws Exception
	{
		Connection con = BankDatabaseConnectivity.getConnection();		
		String queryUpdate = "update hdfcbankdetails set accountNumber=?, accountHolderName = ?, branch=?, amount=? where accountNumber="+accountNumber;
		PreparedStatement ps =  con.prepareStatement(queryUpdate);
		
		ps.setInt(1, hb.getAccountNumber());
		ps.setString(2, hb.getAccountHolderName());
		ps.setString(3, hb.getBranch());
		ps.setInt(4, hb.getAmount());
		
		ps.executeUpdate();

	}
	
	public String deleteBankAccount(int accountNumber) throws Exception
	{
		Connection con = BankDatabaseConnectivity.getConnection();		
		String queryUpdate = "delete from hdfcbankdetails where accountNumber = " +accountNumber;
		PreparedStatement ps =  con.prepareStatement(queryUpdate);
		ps.executeUpdate();

		return "Account Deleted";
	}
		
	public List<HDFCBank> bankDetailsBasedOnBranch(String branchName) throws Exception
	{
		
		 Connection con = BankDatabaseConnectivity.getConnection();
		 String query = "SELECT * FROM HDFCBankDetails";
		 Statement st =  con.createStatement();
		 ResultSet rs =  st.executeQuery(query);
		 
		 List<HDFCBank> detail = new ArrayList<>();
		 
		 while(rs.next())
		 {
			 HDFCBank hb = new HDFCBank();
			 
			 hb.setAccountNumber(rs.getInt("accountNumber"));
			 hb.setAccountHolderName(rs.getString("accountHolderName"));
			 hb.setBranch(rs.getNString("branch"));
			 hb.setAmount(rs.getInt("amount"));
			 
			 detail.add(hb);

		 }
		 
		 ArrayList res = (ArrayList) detail.stream().filter(b->b.getBranch().equalsIgnoreCase(branchName)).collect(Collectors.toList());	 
		
		 
		 return res;
	
	}

	public String transferMoney(int senderAccountNumber, int amount, int receiverAccountNumber) throws Exception
	{
		getAccountBasedOnAccountNumber(senderAccountNumber);
		return null;
		
	}
	
	public List<LoginClass> loginDetail() throws Exception
	{
		
		 Connection con = BankDatabaseConnectivity.getConnection();
		 String query = "SELECT * FROM LOGIN";
		 Statement st =  con.createStatement();
		 ResultSet rs =  st.executeQuery(query);
		 
		 List<LoginClass> detail = new ArrayList<>();
		 
		 while(rs.next())
		 {
			 LoginClass ls = new LoginClass();
			 
			 ls.setUserName(rs.getString("id"));
			 ls.setPassword(rs.getNString("password"));
			 
			 detail.add(ls);

		 }
			
		return detail;	
	}

	public List cheakLoginValid(LoginClass ls) throws Exception 
	
	{
		
		String user = ls.getUserName();
		String pwd = ls.getPassword();
		
		List db = loginDetail();
		
		

		List returnData = new ArrayList();

		if(user==db.get(0)&&pwd==db.get(1)) 
		{
			
			returnData.add("OK");
			
		}
		else
		{
			returnData.add("NO");

			
		}
		return returnData;		
	}
}

	