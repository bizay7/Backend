package com.quinnox.bankwebservoce;


import java.util.*;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/hdfcbank")
public class HDFCBankResource 
{
	
	HDFCBankRepository repository = new HDFCBankRepository();
	
	@GET
	@Path("details")
	@Produces(MediaType.APPLICATION_JSON) // @Proudes takes an array of parameters
	public List<HDFCBank> getAllBankCustomerDetails() throws Exception
	{
		return repository.getAllBankCustomerDetails();
	}
	
	@POST
	@Path("insert")
	//@Consumes(MediaType.APPLICATION_XML)  // It will only accept XML input from user.
	@Consumes(MediaType.APPLICATION_JSON) // For both XML & JSON input.
	public HDFCBank insertAccountDetail(HDFCBank hb) throws Exception
	{
		repository.insertAccountDetail(hb);
		return 	hb;
	
	}

	@GET
	@Path("details/{accountNumber}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<HDFCBank> getAccountBasedOnAccountNumber(@PathParam("accountNumber")int accountNumber) throws Exception
	{													//PathParam are path parameters or variable parts of URL path
		return repository.getAccountBasedOnAccountNumber(accountNumber);
		
	}
	
	@PUT
	@Path("update/{accountNumber}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<HDFCBank> updateAccountName(@PathParam("accountNumber")int accountNumber, HDFCBank hb) throws Exception
	{	
		List<HDFCBank> bothData = new ArrayList<>();
		bothData.addAll(repository.getAccountBasedOnAccountNumber(accountNumber));
		repository.updateAccountName(accountNumber, hb);
		bothData.addAll(repository.getAccountBasedOnAccountNumber(accountNumber));

		return bothData ;
	}
	
	@DELETE
	@Path("delete/{accountNumber}")
	@Produces(MediaType.APPLICATION_JSON)
	public String updateAccountName(@PathParam("accountNumber")int accountNumber) throws Exception
	{
		repository.deleteBankAccount(accountNumber);
		return "Account = "+accountNumber+" is deleled.";
	}
	
	@GET
	@Path("branchdetails/{branchName}")
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public List<HDFCBank> bankBranchDetails(@PathParam("branchName")String branchName) throws Exception
	{
		return repository.bankDetailsBasedOnBranch(branchName);

	}
	
	
	@GET
	@Path("login")
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public List<LoginClass> loginDetails() throws Exception
	{
		
		return repository.loginDetail();

	}
	@POST
	@Path("cheak")
	//@Consumes(MediaType.APPLICATION_XML)  
	@Consumes(MediaType.APPLICATION_JSON) 
	public LoginClass cheakLogin(LoginClass ls) throws Exception
	{
		repository.cheakLoginValid(ls);
		return 	ls;
	}
}
